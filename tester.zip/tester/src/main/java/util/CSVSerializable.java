/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package util;

/**
 *
 * @author aledesma
 */
public interface CSVSerializable {
      // manda objeto a csv
    String toCSV();

    // crea objeto desde un csv
    
}

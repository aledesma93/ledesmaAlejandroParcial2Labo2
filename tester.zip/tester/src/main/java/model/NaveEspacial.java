/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author aledesma
 */
import util.CSVSerializable;
import java.io.Serializable;

/**
 *
 * @author aledesma
 */
public class NaveEspacial implements Comparable<NaveEspacial>, Serializable, CSVSerializable {
    private int id;
    private String nombre;
    private int capacidad;
    private Categoria categoria;

    // Constructor
    public NaveEspacial(int id, String nombre, int capacidad, Categoria categoria) {
        this.id = id;
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.categoria = categoria;
    }

    // Métodos de acceso
    public int getId() {
        return id;
    } 

    public String getNombre() {
        return nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    // Implementación de toCSV
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + capacidad + "," + categoria.name();
    }

    // Implementación de fromCSV
    // Implementación de fromCSV
public static NaveEspacial fromCSV(String csv) {
    String[] partes = csv.split(",", -1); // Divide por comas
    if (partes.length != 4) {
        throw new IllegalArgumentException("El formato del CSV no es válido.");
    }

    int id = Integer.parseInt(partes[0]); // Convertir el ID a entero
    String nombre = partes[1]; // Asignar el nombre
    int capacidad = Integer.parseInt(partes[2]); // Convertir capacidad a entero
    Categoria categoria = Categoria.valueOf(partes[3].toUpperCase()); // Convertir la categoría

    return new NaveEspacial(id, nombre, capacidad, categoria); // Crear un nuevo objeto NaveEspacial
}

    // Implementación de compareTo para orden natural
    @Override
    public int compareTo(NaveEspacial otro) {
        return Integer.compare(this.id, otro.id);
    }

    @Override
    public String toString() {
        return "NaveEspacial{id=" + id + ", nombre='" + nombre + "', capacidad='" + capacidad + "', categoria=" + categoria + "}";
    }
}


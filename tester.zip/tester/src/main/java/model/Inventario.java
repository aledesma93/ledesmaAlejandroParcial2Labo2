/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author aledesma
 */
import util.CSVSerializable;
import service.Serializadora;
/**
 *
 * @author aledesma
 */
import java.util.function.Consumer;

/**
 *
 * @author aledesma
 */
import java.util.*;
import java.io.*;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T extends CSVSerializable & Serializable > {
    private List<T> elementos;

    public Inventario() {
        this.elementos = new ArrayList<>();
    }

    // Agregar elementos
    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    // Obtener elementos por índice
    public T obtener(int indice) {
        if (indice >= 0 && indice < elementos.size()) {
            return elementos.get(indice);
        } else {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
    }

    // Eliminar elementos por índice
    public void eliminar(int indice) {
        if (indice >= 0 && indice < elementos.size()) {
            elementos.remove(indice);
        } else {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
    }

    // Filtrar elementos según un criterio
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }
    public List<T> filtrarPorCategoria(Categoria categoria) {
    return filtrar(elemento -> {
        if (elemento instanceof NaveEspacial) {
            return ((NaveEspacial) elemento).getCategoria() == categoria;
        }
        return false;
    });
}
    public List<T> filtrarPorTitulo(String palabra) {
    return filtrar(elemento -> {
        if (elemento instanceof NaveEspacial) {
            return ((NaveEspacial) elemento).getNombre().toLowerCase().contains(palabra.toLowerCase());
        }
        return false;
    });}
    
    
    // Ordenar de manera natural (por Comparable)
      public void ordenar(Comparator<? super T> comparator) {// especifico orden
        elementos.sort(comparator);
    }
    public void ordenar() {
    elementos.sort(null); // Usa el orden natural comparable
}

    // Guardar en un archivo binario
   
    
   public void guardarEnArchivo(String path) {
    try {
        Serializadora.serializarLista(elementos, path); // Delegar la serialización a Serializadora
        System.out.println("Inventario guardado en el archivo binario: " + path);
    } catch (Exception ex) {
        System.out.println("Error al guardar en archivo binario: " + ex.getMessage());
    }
}
public void cargarDesdeArchivo(String path) {
    try {
        List<T> elementosCargados = Serializadora.deserializarLista(path);
        if (elementosCargados != null) {
            elementos.clear(); // Limpia los elementos actuales del inventario
            elementos.addAll(elementosCargados); // Agrega los elementos cargados
            System.out.println("\n Inventario cargado desde el archivo binario: " + path);
        } else {
            System.out.println("El archivo binario est vacio o no se pudo cargar.");
        }
    } catch (Exception ex) {
        System.out.println("Error al cargar desde archivo binario: " + ex.getMessage());
    }
}
//====================== CSV

public void guardarEnCSV(String path) throws IOException{
    File archivo = new File(path);

    try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
        // encabezado
        bw.write("id,titulo,autor,categoria\n");

        // Escribir cada libro
        for (T item : elementos) {
            if (item instanceof CSVSerializable) { 
                bw.write(((CSVSerializable) item).toCSV() + "\n");
            }
        }

        System.out.println("\n Inventario guardado en CSV: " + path);
    } catch (IOException ex) {
        System.out.println("Error al guardar en CSV: " + ex.getMessage());
    }
}




public void cargarDesdeCSV(String path, Function<String, T> convertidor) throws IOException, ClassNotFoundException{
    File archivo = new File(path);
     this.elementos.clear();

    try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
        String linea;
        br.readLine(); // salta encabezado
        while ((linea = br.readLine()) != null) {
            if (!linea.isBlank()) {
                try {
                    T item = convertidor.apply(linea);
                    agregar(item);
                } catch (IllegalArgumentException e) {
                    System.out.println("Error al procesar linea: " + linea + " - " + e.getMessage());
                }
            }
        }
        System.out.println(" Inventario cargado desde el archivo CSV.");
    } catch (IOException e) {
        System.out.println(" Error al cargar desde archivo CSV: " + e.getMessage());
    }
}

    // Obtener todos los elementos
    public List<T> obtenerTodos() {
        return new ArrayList<>(elementos);
    }
    
    public void paraCadaElemento(Consumer<T> accion) {
        for (T elemento : elementos) {
            accion.accept(elemento);
        }
    }
}
